<?php 
$Receive_email="email here@gmail.com";
$redirect="https://www.google.com/";
?>